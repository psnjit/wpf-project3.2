﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication2
{
    //public enum PatientType
    //{
    //    IN,OUT
    //}
    //class Patient
    //{
    //   public  int patientId;
    //   public string patientName;
    //  public string patientCategory;
    //}

}
