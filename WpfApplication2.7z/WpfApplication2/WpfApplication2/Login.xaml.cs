﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication2;
using System.Collections.ObjectModel;
namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        List<Patient> st = new List<Patient>();
        Patient ob1;
        private void buttom_Click(object sender, RoutedEventArgs e)
        {
            ob1 = new Patient();
            ob1.PatientID = Convert.ToInt32(idbox.Text);
            ob1.Patient_Name = Convert.ToString(namebox.Text);
            ob1.Patient_Type = Convert.ToString(typebox.Text);
            st.Add(ob1);
            idbox.Text = "";
            namebox.Text = "";
            typebox.Text = "";
        }

        private void buttom_Copy_Click(object sender, RoutedEventArgs e)
        {
            stud.DataContext = st;
        }


    }
    public class Patient
    {
        public int PatientID { get; set; }
        public string Patient_Name { get; set; }
        public string Patient_Type { get; set; }
    }
}
